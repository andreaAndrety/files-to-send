<h1 align='center'>
<br>
<strong>
Getting Started
</strong>
</h1>

<h4 align='center'>Aquí encontrarás la base para iniciar el proyecto donde prodras usar los templates para crear el Script, set datos y librerias.</h4>

<p align="center">
<a href="#responsividad">Responsividad</a> •
<a href="#transversales">Transversales</a> •
<a href="#confiabilidad">Confiabilidad</a> •
<a href="#costo-eficientes">Costo Eficientes</a> 
</p>

<br>


